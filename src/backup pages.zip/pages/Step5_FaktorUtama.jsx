import PageWrapper from '../components/PageWrapper';
import Card from '../components/Card';
import Button from '../components/Button';
import BackButton from '../components/BackButton';
import Stepper from '../components/Stepper';
import { useNavigate } from 'react-router-dom';
import { useMPJHD } from '../context/MPJHDContext';
import { useEffect, useState } from 'react';
import {
  hitungNilaiPokokIIIKhususIndividual,
  hitungNilaiPokokIIIKhususBersama,
  hitungNilaiPokokIV,
  hitungNilaiPokokVI,
} from '../utils/hitungNilaiPokok';

export default function Step5_FaktorUtama() {
  const navigate = useNavigate();
  const { state, dispatch } = useMPJHD();
  const [inputUtama, setInputUtama] = useState('');

  const kelompok = state.kelompok || '';
  const subKelompok = state.subKelompok || '';

  useEffect(() => {
    // Kalau kelompok III umum atau V, langsung skip Step5
    if (
      (kelompok === 'III' && (subKelompok === 'umum' || !subKelompok)) ||
      kelompok === 'V'
    ) {
      navigate('/step/6');
    }
  }, [kelompok, subKelompok, navigate]);

  const handleNext = () => {
    // Khusus kelompok selain II, harus isi inputUtama
    if (!inputUtama && kelompok !== 'II') {
      alert('Silakan isi faktor utama terlebih dahulu.');
      return;
    }

    dispatch({ type: 'SET', key: 'inputUtama', value: inputUtama });

    // 🔥 Set nilaiPokok sesuai kelompok
    if (kelompok === 'II') {
      if (state.dampak === 'Unit Kerja') {
        dispatch({ type: 'SET', key: 'nilaiPokok', value: 0 });
      } else if (state.dampak === 'Instansi') {
        dispatch({ type: 'SET', key: 'nilaiPokok', value: 30 });
      } else if (state.dampak === 'Negara') {
        dispatch({ type: 'SET', key: 'nilaiPokok', value: 60 });
      }
    }
    else if (kelompok === 'III' && subKelompok === 'khusus_individual') {
      dispatch({ type: 'SET', key: 'nilaiPokok', value: hitungNilaiPokokIIIKhususIndividual(Number(inputUtama)) });
    }
    else if (kelompok === 'III' && subKelompok === 'khusus_bersama') {
      dispatch({ type: 'SET', key: 'nilaiPokok', value: hitungNilaiPokokIIIKhususBersama(inputUtama) });
    }
    else if (kelompok === 'IV') {
      dispatch({ type: 'SET', key: 'nilaiPokok', value: hitungNilaiPokokIV(Number(inputUtama)) });
    }
    else if (kelompok === 'VI') {
      dispatch({ type: 'SET', key: 'nilaiPokok', value: hitungNilaiPokokVI(inputUtama) });
    }

    navigate('/step/6');
  };

  return (
    <PageWrapper>
      <h1 className="text-2xl font-bold text-center mb-8">
        Faktor Utama
      </h1>

      <Card>
        {kelompok === 'II' ? (
          <div className="flex flex-col gap-6 text-center">
            <p className="text-gray-700 dark:text-gray-200">
              Kelompok II tidak perlu mengisi faktor utama.
            </p>
            <p className="text-gray-700 dark:text-gray-200">
              Lanjutkan untuk mengisi faktor pembobotan tambahan.
            </p>

            <div className="flex justify-between gap-4 mt-6">
              <BackButton className="flex-1" />
              <Button onClick={handleNext} className="flex-1">
                Lanjut
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-6">
            {/* Render dinamis berdasarkan kelompok */}

            {kelompok === 'III' && subKelompok === 'khusus_individual' && (
              <div className="flex flex-col gap-2">
                <p className="text-center text-gray-700 dark:text-gray-200">
                  Masukkan jumlah kerugian atau penerimaan (dalam Rupiah):
                </p>
                <input
                  type="number"
                  placeholder="Contoh: 5000000"
                  className="p-2 border rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                  value={inputUtama}
                  onChange={(e) => setInputUtama(e.target.value)}
                />
              </div>
            )}

            {kelompok === 'III' && subKelompok === 'khusus_bersama' && (
              <div className="flex flex-col gap-4">
                <p className="text-center text-gray-700 dark:text-gray-200">
                  Pilih peran pelaku:
                </p>
                {['Pasif', 'Aktif', 'Inisiator'].map((item) => (
                  <label key={item} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="peran"
                      value={item}
                      checked={inputUtama === item}
                      onChange={(e) => setInputUtama(e.target.value)}
                      className="accent-primary"
                    />
                    {item}
                  </label>
                ))}
              </div>
            )}

            {kelompok === 'IV' && (
              <div className="flex flex-col gap-2">
                <p className="text-center text-gray-700 dark:text-gray-200">
                  Masukkan nilai kerugian pihak yang dilayani (dalam Rupiah):
                </p>
                <input
                  type="number"
                  placeholder="Contoh: 1000000"
                  className="p-2 border rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                  value={inputUtama}
                  onChange={(e) => setInputUtama(e.target.value)}
                />
              </div>
            )}

            {kelompok === 'VI' && (
              <div className="flex flex-col gap-4">
                <p className="text-center text-gray-700 dark:text-gray-200">
                  Tingkat dampak pelanggaran terhadap reputasi:
                </p>
                {['Tidak Berdampak', 'Unit Kerja', 'Instansi/Tersangka'].map((item) => (
                  <label key={item} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="dampakVI"
                      value={item}
                      checked={inputUtama === item}
                      onChange={(e) => setInputUtama(e.target.value)}
                      className="accent-primary"
                    />
                    {item}
                  </label>
                ))}
              </div>
            )}

            <div className="flex justify-between gap-4 mt-6">
              <BackButton className="flex-1" />
              <Button onClick={handleNext} className="flex-1">
                Lanjut
              </Button>
            </div>
          </div>
        )}
      </Card>

      <Stepper currentStep={5} />
    </PageWrapper>
  );
}
