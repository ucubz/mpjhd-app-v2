// utils_v2/pengelompokanPasal.js

export const daftarPasalPerKategori = {
  PASAL_3: [
    'Pasal 3 huruf a',
    'Pasal 3 huruf b',
    'Pasal 3 huruf c',
    'Pasal 3 huruf d',
    'Pasal 3 huruf e',
    'Pasal 3 huruf f'
  ],
  PASAL_4: [
    'Pasal 4 huruf a',
    'Pasal 4 huruf b',
    'Pasal 4 huruf c',
    'Pasal 4 huruf d',
    'Pasal 4 huruf e',
    'Pasal 4 huruf f',
    'Pasal 4 huruf g',
    'Pasal 4 huruf h'
  ],
  PASAL_5: [
    'Pasal 5 huruf a',
    'Pasal 5 huruf b',
    'Pasal 5 huruf c',
    'Pasal 5 huruf d',
    'Pasal 5 huruf e',
    'Pasal 5 huruf f',
    'Pasal 5 huruf g',
    'Pasal 5 huruf h',
    'Pasal 5 huruf i',
    'Pasal 5 huruf j',
    'Pasal 5 huruf k',
    'Pasal 5 huruf l',
    'Pasal 5 huruf m',
    'Pasal 5 angka 2',
    'Pasal 5 angka 3',
    'Pasal 5 angka 4',
    'Pasal 5 angka 5',
    'Pasal 5 angka 6',
    'Pasal 5 angka 7'
  ]
};
