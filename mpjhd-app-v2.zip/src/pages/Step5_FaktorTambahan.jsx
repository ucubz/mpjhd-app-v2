import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMPJHD } from '../context/MPJHDContext';
import PageWrapper from '../components/PageWrapper';
import Card from '../components/Card';
import Stepper from '../components/Stepper';
import Button from '../components/Button';

export default function Step5_FaktorTambahan() {
  const navigate = useNavigate();
  const { dispatch } = useMPJHD();

  const [form, setForm] = useState({
    banyakPasal: '',
    hukdis: '',
    kesengajaan: '',
    hambatan: '',
  });

  const [error, setError] = useState('');

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    dispatch({ type: 'SET_FAKTOR_PEMBOBOTAN', field, value });
  };

  const handleNext = () => {
    const allFilled = Object.values(form).every((v) => v !== '');
    if (!allFilled) return setError('Semua faktor wajib dipilih');
    navigate('/step/6');
  };

  return (
    <PageWrapper>
      <Stepper totalSteps={7} />
      <Card>
        <h2 className="text-xl font-bold mb-4 text-center">Faktor Pembobotan Tambahan</h2>

        <div className="flex flex-col gap-4">
          <Dropdown
            label="Jumlah Pasal yang Dilanggar"
            value={form.banyakPasal}
            onChange={(val) => handleChange('banyakPasal', val)}
            options={[
              { label: 'Satu Pasal', value: 'satu' },
              { label: 'Dua Pasal', value: 'dua' },
              { label: 'Lebih dari Dua', value: 'lebihDariDua' },
            ]}
          />

          <Dropdown
            label="Riwayat Hukuman Disiplin"
            value={form.hukdis}
            onChange={(val) => handleChange('hukdis', val)}
            options={[
              { label: 'Belum Pernah', value: 'belumPernah' },
              { label: 'Pernah 1 Kali', value: 'pernah1x' },
              { label: 'Pernah Lebih dari 1 Kali', value: 'lebihDari1x' },
            ]}
          />

          <Dropdown
            label="Unsur Kesengajaan"
            value={form.kesengajaan}
            onChange={(val) => handleChange('kesengajaan', val)}
            options={[
              { label: 'Terpaksa Melakukan', value: 'terpaksa' },
              { label: 'Tidak Sengaja / Lalai', value: 'lalai' },
              { label: 'Sengaja', value: 'sengaja' },
            ]}
          />

          <Dropdown
            label="Hambatan dalam Pemeriksaan"
            value={form.hambatan}
            onChange={(val) => handleChange('hambatan', val)}
            options={[
              { label: 'Tidak Ada Hambatan', value: 'tidakAda' },
              { label: 'Tidak Kooperatif / Berbelit-belit', value: 'berbelit' },
              { label: 'Menghalangi / Menghilangkan Bukti', value: 'menghalangi' },
            ]}
          />

          {error && <p className="text-red-600 text-sm">{error}</p>}

          <div className="mt-6 flex justify-end">
            <Button onClick={handleNext}>Lanjut</Button>
          </div>
        </div>
      </Card>
    </PageWrapper>
  );
}

function Dropdown({ label, value, onChange, options }) {
  return (
    <div>
      <label className="block text-sm font-semibold mb-1">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border rounded px-3 py-2"
      >
        <option value="">Pilih...</option>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}
