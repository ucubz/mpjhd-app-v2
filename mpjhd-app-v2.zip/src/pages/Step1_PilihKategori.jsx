import { useNavigate } from 'react-router-dom';
import { useMPJHD } from '../context/MPJHDContext';
import PageWrapper from '../components/PageWrapper';
import Card from '../components/Card';
import Stepper from '../components/Stepper';

const options = [
  { value: 'PASAL_3', label: 'Kewajiban - Pasal 3' },
  { value: 'PASAL_4', label: 'Larangan - Pasal 4' },
  { value: 'PASAL_5', label: 'Larangan - Pasal 5' },
  { value: 'IZIN', label: 'Izin Perkawinan dan Perceraian' },
];

export default function Step1_PilihKategori() {
  const navigate = useNavigate();
  const { dispatch } = useMPJHD();

  const handleSelect = (value) => {
    dispatch({ type: 'SET', field: 'kategori', value });

    if (value === 'IZIN') {
      dispatch({ type: 'SET', field: 'kelompok', value: 'VI' });
      navigate('/step/3'); // langsung lompat karena tidak perlu pilih pasal
    } else {
      navigate('/step/2');
    }
  };

  return (
    <PageWrapper>
      <Stepper totalSteps={7} />
      <Card>
        <h2 className="text-xl font-bold mb-4 text-center">Pilih Jenis Pelanggaran</h2>
        <div className="flex flex-col gap-3">
          {options.map((opt) => (
            <button
              key={opt.value}
              onClick={() => handleSelect(opt.value)}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-600 px-4 py-2 text-left
                         hover:bg-blue-100 dark:hover:bg-gray-700 transition-all"
            >
              {opt.label}
            </button>
          ))}
        </div>
      </Card>
    </PageWrapper>
  );
}
