import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMPJHD } from '../context/MPJHDContext';
import PageWrapper from '../components/PageWrapper';
import Card from '../components/Card';
import Stepper from '../components/Stepper';
import Button from '../components/Button';

export default function Step4_FaktorUtama() {
  const navigate = useNavigate();
  const { state, dispatch } = useMPJHD();
  const { kelompok } = state;

  const [kerugian, setKerugian] = useState('');
  const [peran, setPeran] = useState('');
  const [reputasi, setReputasi] = useState('');
  const [error, setError] = useState('');

  const handleNext = () => {
    const faktor = {};

    if (kelompok === 'IV' && !kerugian) return setError('Pilih besaran kerugian pihak dilayani');
    if (kelompok === 'VI' && !reputasi) return setError('Pilih dampak terhadap reputasi');
    if (kelompok === 'III Khusus Bersama' && (!kerugian || !peran))
      return setError('Pilih peran dan jumlah kerugian');

    if (kelompok === 'III Khusus Individual' && !kerugian)
      return setError('Pilih jumlah kerugian pelaku individual');

    if (kerugian) faktor.kerugian = kerugian;
    if (peran) faktor.peran = peran;
    if (reputasi) faktor.reputasi = reputasi;

    dispatch({ type: 'SET_FAKTOR_UTAMA', field: 'faktor', value: faktor });
    navigate('/step/5');
  };

  return (
    <PageWrapper>
      <Stepper totalSteps={7} />
      <Card>
        <h2 className="text-xl font-bold mb-4 text-center">Faktor Utama</h2>

        {kelompok === 'IV' && (
          <div className="mb-4">
            <p className="mb-2 font-semibold">Pilih kerugian pihak dilayani:</p>
            <select
              value={kerugian}
              onChange={(e) => setKerugian(e.target.value)}
              className="w-full border rounded p-2"
            >
              <option value="">Pilih...</option>
              <option value="≤10jt">≤ 10 juta</option>
              <option value="10-50jt">&gt 10 juta s.d. 50 juta</option>
              <option value="50-100jt">&gt 50 juta s.d. 100 juta</option>
              <option value=">100jt">&gt 100 juta</option>
            </select>
          </div>
        )}

        {kelompok === 'VI' && (
          <div className="mb-4">
            <p className="mb-2 font-semibold">Pilih dampak terhadap reputasi instansi:</p>
            <select
              value={reputasi}
              onChange={(e) => setReputasi(e.target.value)}
              className="w-full border rounded p-2"
            >
              <option value="">Pilih...</option>
              <option value="Ringan">Ringan</option>
              <option value="Sedang">Sedang</option>
              <option value="Berat">Berat</option>
            </select>
          </div>
        )}

        {kelompok === 'III Khusus Individual' && (
          <div className="mb-4">
            <p className="mb-2 font-semibold">Pilih kerugian negara:</p>
            <select
              value={kerugian}
              onChange={(e) => setKerugian(e.target.value)}
              className="w-full border rounded p-2"
            >
              <option value="">Pilih...</option>
              <option value="≤10jt">≤ 10 juta</option>
              <option value="10-50jt">&gt 10 juta s.d. 50 juta</option>
              <option value="50-100jt">&gt 50 juta s.d. 100 juta</option>
              <option value=">100jt">&gt 100 juta</option>
            </select>
          </div>
        )}

        {kelompok === 'III Khusus Bersama' && (
          <>
            <div className="mb-4">
              <p className="mb-2 font-semibold">Pilih peran pelaku:</p>
              <select
                value={peran}
                onChange={(e) => setPeran(e.target.value)}
                className="w-full border rounded p-2"
              >
                <option value="">Pilih...</option>
                <option value="Pasif">Pasif</option>
                <option value="Aktif">Aktif</option>
                <option value="Inisiator">Inisiator</option>
              </select>
            </div>

            <div className="mb-4">
              <p className="mb-2 font-semibold">Pilih jumlah kerugian negara:</p>
              <select
                value={kerugian}
                onChange={(e) => setKerugian(e.target.value)}
                className="w-full border rounded p-2"
              >
                <option value="">Pilih...</option>
                <option value="≤10jt">≤ 10 juta</option>
                <option value="10-50jt">&gt 10 juta s.d. 50 juta</option>
                <option value="50-100jt">&gt 50 juta s.d. 100 juta</option>
                <option value=">100jt">&gt 100 juta</option>
              </select>
            </div>
          </>
        )}

        {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

        <div className="mt-6 flex justify-end">
          <Button onClick={handleNext}>Lanjut</Button>
        </div>
      </Card>
    </PageWrapper>
  );
}
