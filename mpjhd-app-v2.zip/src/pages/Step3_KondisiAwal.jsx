import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMPJHD } from '../context/MPJHDContext';
import { tentukanKelompok } from '../utils_v2/tentukanKelompok';
import PageWrapper from '../components/PageWrapper';
import Card from '../components/Card';
import Stepper from '../components/Stepper';
import Button from '../components/Button';

export default function Step3_KondisiAwal() {
  const navigate = useNavigate();
  const { state, dispatch } = useMPJHD();
  const { pasalUtama, kategori, kelompok } = state;

  const [dampak, setDampak] = useState('');
  const [jabatan, setJabatan] = useState('');
  const [adaKerugian, setAdaKerugian] = useState(null);

  const [error, setError] = useState('');

  useEffect(() => {
    if (!kelompok && pasalUtama) {
      const hasilKelompok = tentukanKelompok(pasalUtama);
      dispatch({ type: 'SET', field: 'kelompok', value: hasilKelompok });
    }
  }, [pasalUtama, kelompok, dispatch]);

  const handleNext = () => {
    if (state.kelompok === 'II' && !dampak) {
      setError('Pilih dampak pelanggaran terlebih dahulu');
      return;
    }

    if (state.kelompok === 'V' && !jabatan) {
      setError('Pilih jabatan pelaku terlebih dahulu');
      return;
    }

    if (state.kelompok === 'III' && adaKerugian === null) {
      setError('Tentukan apakah ada kerugian atau penerimaan uang');
      return;
    }

    if (dampak) dispatch({ type: 'SET', field: 'dampak', value: dampak });
    if (jabatan) dispatch({ type: 'SET', field: 'jabatan', value: jabatan });
    if (adaKerugian !== null) dispatch({ type: 'SET', field: 'adaKerugian', value: adaKerugian });

    navigate('/step/4');
  };

  return (
    <PageWrapper>
      <Stepper totalSteps={7} />
      <Card>
        <h2 className="text-xl font-bold mb-4 text-center">Kondisi Awal Berdasarkan Pasal</h2>

        {state.kelompok === 'II' && (
          <div className="mb-4">
            <p className="mb-2 font-semibold">Pilih dampak pelanggaran:</p>
            <div className="flex flex-col gap-2">
              {['Unit Kerja', 'Instansi', 'Negara'].map((val) => (
                <label key={val} className="cursor-pointer">
                  <input
                    type="radio"
                    name="dampak"
                    value={val}
                    checked={dampak === val}
                    onChange={() => setDampak(val)}
                    className="mr-2"
                  />
                  {val}
                </label>
              ))}
            </div>
          </div>
        )}

        {state.kelompok === 'V' && (
          <div className="mb-4">
            <p className="mb-2 font-semibold">Pilih jabatan pelaku:</p>
            <div className="flex flex-col gap-2">
              {['Administrator/Fungsional', 'Pimpinan Tinggi/Lainnya'].map((val) => (
                <label key={val} className="cursor-pointer">
                  <input
                    type="radio"
                    name="jabatan"
                    value={val}
                    checked={jabatan === val}
                    onChange={() => setJabatan(val)}
                    className="mr-2"
                  />
                  {val}
                </label>
              ))}
            </div>
          </div>
        )}

        {state.kelompok === 'III' && (
          <div className="mb-4">
            <p className="mb-2 font-semibold">Apakah ada penerimaan uang atau kerugian negara?</p>
            <div className="flex gap-4">
              <button
                onClick={() => setAdaKerugian(true)}
                className={`px-4 py-2 rounded-lg border ${
                  adaKerugian === true ? 'bg-blue-600 text-white' : 'bg-white'
                }`}
              >
                Ada
              </button>
              <button
                onClick={() => setAdaKerugian(false)}
                className={`px-4 py-2 rounded-lg border ${
                  adaKerugian === false ? 'bg-blue-600 text-white' : 'bg-white'
                }`}
              >
                Tidak Ada
              </button>
            </div>
          </div>
        )}

        {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

        <div className="mt-6 flex justify-end">
          <Button onClick={handleNext}>Lanjut</Button>
        </div>
      </Card>
    </PageWrapper>
  );
}
