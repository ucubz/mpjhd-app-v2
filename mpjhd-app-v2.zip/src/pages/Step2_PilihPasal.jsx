import { useNavigate } from 'react-router-dom';
import { useMPJHD } from '../context/MPJHDContext';
import { daftarPasalPerKategori } from '../utils_v2/pengelompokanPasal';
import PageWrapper from '../components/PageWrapper';
import Card from '../components/Card';
import Stepper from '../components/Stepper';

export default function Step2_PilihPasal() {
  const navigate = useNavigate();
  const { state, dispatch } = useMPJHD();
  const { kategori } = state;

  const pasalList = daftarPasalPerKategori[kategori] || [];

  const handlePilihPasal = (pasal) => {
    dispatch({ type: 'SET', field: 'pasalUtama', value: pasal });
    navigate('/step/3');
  };

  return (
    <PageWrapper>
      <Stepper totalSteps={7} />
      <Card>
        <h2 className="text-xl font-bold mb-4 text-center">Pilih Pasal yang Dilanggar</h2>
        <div className="flex flex-col gap-3">
          {pasalList.map((pasal) => (
            <button
              key={pasal}
              onClick={() => handlePilihPasal(pasal)}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-600 px-4 py-2 text-left
                         hover:bg-blue-100 dark:hover:bg-gray-700 transition-all"
            >
              {pasal}
            </button>
          ))}
        </div>
      </Card>
    </PageWrapper>
  );
}
