import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMPJHD, useResetMPJHD } from '../context/MPJHDContext';
import PageWrapper from '../components/PageWrapper';
import Card from '../components/Card';
import Stepper from '../components/Stepper';
import Button from '../components/Button';
import SalinClipboardButton from '../components/SalinClipboardButton';
import { hitungNilaiAkhir } from '../utils_v2/hitungNilaiAkhir';
import { konversiGrade } from '../utils_v2/konversiGrade';

export default function Step7_HasilAkhir() {
  const navigate = useNavigate();
  const reset = useResetMPJHD();
  const { state, dispatch } = useMPJHD();
  const [hasil, setHasil] = useState({});

  useEffect(() => {
    const hasilHitung = hitungNilaiAkhir(state);
    const { grade, jenisHukuman } = konversiGrade(state.kelompok, hasilHitung);
    setHasil({ ...hasilHitung, grade, jenisHukuman });

    dispatch({ type: 'SET', field: 'nilaiAkhir', value: hasilHitung });
    dispatch({ type: 'SET', field: 'grade', value: grade });
    dispatch({ type: 'SET', field: 'jenisHukuman', value: jenisHukuman });
    dispatch({ type: 'SET_FINISHED', value: true });
  }, [state, dispatch]);

  const faktorTambahanLabels = {
    banyakPasal: {
      satu: 'Satu Pasal (0)',
      dua: 'Dua Pasal (5)',
      lebihDariDua: 'Lebih dari Dua (10)',
    },
    hukdis: {
      belumPernah: 'Belum Pernah (0)',
      pernah1x: 'Pernah 1 Kali (5)',
      lebihDari1x: 'Pernah Lebih dari 1 Kali (10)',
    },
    kesengajaan: {
      terpaksa: 'Terpaksa (0)',
      lalai: 'Tidak Sengaja / Lalai (5)',
      sengaja: 'Sengaja (10)',
    },
    hambatan: {
      tidakAda: 'Tidak Ada Hambatan (0)',
      berbelit: 'Tidak Kooperatif / Berbelit-belit (5)',
      menghalangi: 'Menghalangi / Menghilangkan Bukti (10)',
    },
  };

  const handleReset = () => {
    reset();
    navigate('/step/1');
  };

  return (
    <PageWrapper>
      <Stepper totalSteps={7} />
      <Card>
        <h2 className="text-xl font-bold mb-4 text-center">Hasil Akhir Perhitungan MPJHD</h2>

        <div id="hasil-tabel" className="whitespace-pre-wrap text-sm leading-relaxed text-gray-800 dark:text-gray-100">
{`Nilai Pokok Pelanggaran: ${state.nilaiPokok}

${state.faktorUtama.peran ? `Faktor Peran:
  a. Peran pelaku: ${state.faktorUtama.peran} (${state.faktorUtama.nilaiPeran ?? '-'})\n` : ''}

${state.faktorUtama.kerugian || state.faktorUtama.reputasi ? `Faktor Utama:
  a. ${state.faktorUtama.kerugian ? `Besaran kerugian: ${state.faktorUtama.kerugian}` : `Dampak terhadap reputasi: ${state.faktorUtama.reputasi}`} (${state.faktorUtama.nilaiFaktor ?? '-'})\n` : ''}

Faktor Tambahan:
  a. Banyaknya pasal: ${faktorTambahanLabels.banyakPasal[state.faktorPembobotan.banyakPasal] || '-'}
  b. Riwayat hukuman: ${faktorTambahanLabels.hukdis[state.faktorPembobotan.hukdis] || '-'}
  c. Unsur kesengajaan: ${faktorTambahanLabels.kesengajaan[state.faktorPembobotan.kesengajaan] || '-'}
  d. Hambatan pemeriksaan: ${faktorTambahanLabels.hambatan[state.faktorPembobotan.hambatan] || '-'}
  Total faktor tambahan: ${hasil.faktorTambahan ?? '-'}

Faktor yang Meringankan:
  a. Kooperatif: ${state.faktorMeringankan.kooperatif ? '✔ (5)' : '✘ (0)'}
  b. Inisiator: ${state.faktorMeringankan.inisiator ? '✔ (10)' : '✘ (0)'}
  Total pengurang meringankan: ${hasil.faktorMeringankan ?? '-'}

TOTAL NILAI: ${hasil.nilaiAkhir ?? '-'}
GRADE: ${hasil.grade || '-'}
JENIS HUKUMAN DISIPLIN: ${hasil.jenisHukuman || '-'}`}
        </div>

        <div className="mt-6 flex flex-wrap gap-3 justify-between">
          <Button onClick={() => navigate('/step/6')}>Kembali</Button>
          <SalinClipboardButton targetId="hasil-tabel" />
          <Button onClick={handleReset}>Reset</Button>
        </div>
      </Card>
    </PageWrapper>
  );
}
