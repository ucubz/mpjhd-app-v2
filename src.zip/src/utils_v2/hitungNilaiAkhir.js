import { hitungNilaiKelompokI } from './hitungNilaiKelompokI';
import { tentukanNilaiPokok } from './tentukanNilaiPokok';
import { hitungFaktorTambahan } from './hitungFaktorTambahan';
import { hitungFaktorMeringankan } from './hitungFaktorMeringankan';

/**
 * Menghitung nilai akhir MPJHD berdasarkan seluruh state.
 * Rumus: Nilai Pokok + (Peran atau Faktor Utama + Tambahan) - Meringankan
 *
 * @param {object} state - Seluruh state dari context MPJHD
 * @returns {object} hasil: { nilaiPokok, nilaiTambahan, pengurangMeringankan, nilaiAkhir }
 */
export function hitungNilaiAkhir(state) {
  const kelompok = String(state.kelompok || '').toUpperCase();

  if (kelompok === 'I') {
    const jumlahHari = state.jumlahHariTidakMasuk || 0;
    const nilaiPokok = hitungNilaiKelompokI(jumlahHari);

    console.log('[DEBUG] Kelompok I');
    console.log('[DEBUG] jumlahHariTidakMasuk:', jumlahHari);
    console.log('[DEBUG] nilaiPokok:', nilaiPokok);

    return {
      nilaiPokok,
      nilaiTambahan: 0,
      pengurangMeringankan: 0,
      nilaiAkhir: nilaiPokok,
    };
  }

  const nilaiPokok = tentukanNilaiPokok(
    state.kelompok,
    state.pasalUtama,
    state.dampak,
    state.jabatan
  );

  let nilaiUtama = 0;
  let nilaiTambahan = 0;

  if (kelompok === 'III_BERSAMA') {
    // Peran = faktor utama, jumlahKerugian = faktor tambahan
    nilaiUtama = state.faktorUtama.nilai || 0;
    nilaiTambahan = hitungFaktorTambahan(state.faktorPembobotan, kelompok);
  } else {
    // Kelompok lain: nilai faktor utama + faktor tambahan
    nilaiUtama = state.faktorUtama.nilai || 0;
    nilaiTambahan = hitungFaktorTambahan(state.faktorPembobotan, kelompok);
  }

  const pengurangMeringankan = hitungFaktorMeringankan(state.faktorMeringankan);
  const nilaiAkhir = nilaiPokok + nilaiUtama + nilaiTambahan - pengurangMeringankan;

  console.log('[DEBUG] Kelompok:', kelompok);
  console.log('[DEBUG] pasal:', state.pasalUtama);
  console.log('[DEBUG] nilaiPokok:', nilaiPokok);
  console.log('[DEBUG] faktorUtama:', state.faktorUtama);
  console.log('[DEBUG] nilaiUtama:', nilaiUtama);
  console.log('[DEBUG] faktorPembobotan:', state.faktorPembobotan);
  console.log('[DEBUG] nilaiTambahan:', nilaiTambahan);
  console.log('[DEBUG] faktorMeringankan:', state.faktorMeringankan);
  console.log('[DEBUG] pengurangMeringankan:', pengurangMeringankan);
  console.log('[DEBUG] nilaiAkhir:', nilaiAkhir);

  return {
    nilaiPokok,
    nilaiTambahan: nilaiUtama + nilaiTambahan,
    pengurangMeringankan,
    nilaiAkhir,
  };
}
